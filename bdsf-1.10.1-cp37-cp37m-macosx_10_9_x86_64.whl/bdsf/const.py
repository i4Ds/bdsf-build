"""Constants

Some universal constants
"""

import math

pi=math.pi
fwsig=2.35482
rad=180.0/pi
c=2.99792458e8
bolt=1.3806505e-23
sq2=math.sqrt(2)

